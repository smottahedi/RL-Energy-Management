.. _Development:

Development
===========

The development site of this software is at https://github.com/lbl-srg/EnergyplusToFMU.

To clone the master branch, type
   
git clone https://github.com/lbl-srg/EnergyplusToFMU.git


